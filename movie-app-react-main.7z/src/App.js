import React from 'react'
import './App.css';
import MovieData from './MovieData';
function App() {
  return (
    <div className="App">
  <MovieData/>
    </div>
  );
}

export default App;
